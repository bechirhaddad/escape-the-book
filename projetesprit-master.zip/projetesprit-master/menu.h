#include<stdlib.h>
#include<stdio.h>
#include <string.h>
#include <math.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_getenv.h>
#ifndef DEF_CONSTANTES
#define DEF_CONSTANTES

void afficher();

#define LARGEUR_FENETRE 1000
#define HAUTEUR_FENETRE 550


#endif
