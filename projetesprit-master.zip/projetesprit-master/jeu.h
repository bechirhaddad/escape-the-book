#include<SDL/SDL.H>

#define TAILLE_BLOC 34

enum{HAUT,BAS,GAUCHE,DROIRE}
enum{VIDE,MUR,LINK};//0,1,2;


void jouer(SDL_Surface* ecran);

