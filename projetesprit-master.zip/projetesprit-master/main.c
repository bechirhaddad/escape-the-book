#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#include "menu.h"

int main(){
    afficher();
return 0; 
 }     
      

  
            

		

        


